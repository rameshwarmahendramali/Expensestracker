package com.example.expensetracker;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Savings extends AppCompatActivity implements ValueEventListener {
    TextView total_saving, day_saving, month_saving, week_saving;
    int total_spend;
    DatabaseReference d_ref;
    Cursor c;
    long differenceDates;
    int i;
    int monthly_spending = 0;
    String username1;
    int w_sum;
    ArrayList<String> arr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_savings);

        total_saving = findViewById(R.id.txtToShowTotalSavings);
        day_saving = findViewById(R.id.txtTOSavedToday);
        month_saving = findViewById(R.id.textView13);
        week_saving = findViewById(R.id.txtToShowWeeklySavings);
        arr = new ArrayList<>();

        MyHelper helper = new MyHelper(getApplicationContext());
        SQLiteDatabase database = helper.getReadableDatabase();
        c = database.rawQuery("select * from USER", new String[]{});

        if (c != null && c.moveToFirst()) {
            username1 = c.getString(1);
        }

        d_ref = FirebaseDatabase.getInstance().getReference("users").child(username1);
        d_ref.addValueEventListener(this);
    }

    String getcurrneDate() {
        return new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
    }

    String getyear() {
        return getcurrneDate().split("-")[2];
    }

    String getmonth() {
        return getcurrneDate().split("-")[1];
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onDataChange(@NonNull DataSnapshot snapshot) {
        if (snapshot.child("total_spending").getValue() != null) {
            total_spend = Integer.parseInt(snapshot.child("total_spending").getValue().toString());
        } else {
            total_spend = 0; // or any default value
        }

        if (snapshot.child("EXpenseOut").child(getyear()).child(getmonth()).child("monthly_spend").exists()) {
            monthly_spending = Integer.parseInt(snapshot.child("EXpenseOut").child(getyear()).child(getmonth())
                    .child("monthly_spend").getValue().toString());
        }

        int spend = Integer.parseInt(snapshot.child("spend").getValue(String.class));
        int day_buget = spend / returnMonthDays();

        if (snapshot.child("EXpenseOut").child(getyear()).child(getmonth()).child(getcurrneDate()).exists()) {
            int sum = 0;
            for (DataSnapshot dataSnapshot : snapshot.child("EXpenseOut").child(getyear()).child(getmonth())
                    .child(getcurrneDate()).getChildren()) {
                String s = dataSnapshot.getKey();
                sum += Integer.parseInt(snapshot.child("EXpenseOut").child(getyear()).child(getmonth())
                        .child(getcurrneDate()).child(s).child("day_amount").getValue().toString());
            }
            day_saving.setText((day_buget - sum) + " Rs.");
        } else {
            day_saving.setText(day_buget + " Rs.");
        }

        // Monthly Saving and Total Saving
        DataSnapshot totalSavingSnapshot = snapshot.child("total_saving");
        if (totalSavingSnapshot.getValue() != null) {
            String[] temp = totalSavingSnapshot.getValue().toString().split("-");
            if (temp.length == 3 && temp[1].equals(getmonth()) && temp[2].equals(getyear())) {
                int diff = (Integer.parseInt(getcurrneDate().split("-")[0]) - Integer.parseInt(temp[0])) + 1;
                month_saving.setText(((diff * day_buget) - monthly_spending) + " Rs.");
            } else {
                month_saving.setText((((Integer.parseInt(getcurrneDate().split("-")[0]) * day_buget) - monthly_spending) + " Rs."));
            }

            try {
                long l = numberofDaysBetweenTwoDays(totalSavingSnapshot.getValue().toString(), getcurrneDate());
                total_saving.setText(((l * day_buget) - total_spend) + " Rs.");
            } catch (ParseException e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Missing total_saving data", Toast.LENGTH_SHORT).show();
            month_saving.setText("0 Rs.");
            total_saving.setText("0 Rs.");
        }

        // Weekly Saving
        arr.clear();
        for (DataSnapshot dataSnapshot : snapshot.child("EXpenseOut").child(getyear()).child(getmonth()).getChildren()) {
            if (!dataSnapshot.getKey().equals("monthly_spend")) {
                arr.add(dataSnapshot.getKey());
            }
        }

        i = Math.max(0, arr.size() - 7);
        w_sum = 0;

        while (i < arr.size()) {
            String date = arr.get(i);
            int d = Integer.parseInt(getcurrneDate().split("-")[0]) - Integer.parseInt(date.split("-")[0]);
            if (d > 7) {
                i++;
            } else {
                for (DataSnapshot dataSnapshot : snapshot.child("EXpenseOut").child(getyear()).child(getmonth())
                        .child(date).getChildren()) {
                    String s = dataSnapshot.getKey();
                    w_sum += Integer.parseInt(snapshot.child("EXpenseOut").child(getyear()).child(getmonth())
                            .child(date).child(s).child("day_amount").getValue().toString());
                }
                i++;
            }
        }

        int daysSinceStart = Integer.parseInt(getcurrneDate().split("-")[0])
                - (totalSavingSnapshot.getValue() != null
                ? Integer.parseInt(totalSavingSnapshot.getValue().toString().split("-")[0]) : 0) + 1;

        if (daysSinceStart >= 7) {
            week_saving.setText(((7 * day_buget) - w_sum) + " Rs.");
        } else {
            week_saving.setText(((daysSinceStart * day_buget) - w_sum) + " Rs.");
        }
    }

    @Override
    public void onCancelled(@NonNull DatabaseError error) {
    }

    int returnMonthDays() {
        switch (getmonth()) {
            case "01": case "03": case "05": case "07": case "08": case "10": case "12": return 31;
            case "04": case "06": case "09": case "11": return 30;
            case "02": return check_leap_year(Integer.parseInt(getyear())) ? 29 : 28;
        }
        return 1;
    }

    boolean check_leap_year(int year) {
        return ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0);
    }

    long numberofDaysBetweenTwoDays(String before, String after) throws ParseException {
        differenceDates = 1;
        try {
            SimpleDateFormat dates = new SimpleDateFormat("dd-MM-yyyy");
            Date date1 = dates.parse(after);
            Date date2 = dates.parse(before);
            long difference = Math.abs(date1.getTime() - date2.getTime());
            differenceDates = difference / (24 * 60 * 60 * 1000);
            return differenceDates + 1;
        } catch (Exception e) {
            return differenceDates;
        }
    }
}
